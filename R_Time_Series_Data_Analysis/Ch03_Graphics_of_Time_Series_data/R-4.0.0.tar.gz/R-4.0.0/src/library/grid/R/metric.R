
# API to access detailed text metric info
#
#  Copyright (C) 1995-2012 The R Core Team

# This first function does NOT return a "unit" object
# It is just access to font metric info in the calling context
# (similar to the convert*() functions, with corresponding caveats on use)

grid.textMetric <- function(string) {

}

# It should be possible to define units like "strascent" and "strdescent"
